public class Dish {
    protected Dish left;
    protected Dish right;
    protected String name;
    protected boolean glutenFree;
    protected int calories;

    //default constructor
    public Dish()
    {
        left = null;
        right = null;
        name = null;
        glutenFree =false;
        calories = 0;
    }

    //constructor with args
    public Dish(String n, int cal, boolean gf)
    {
        left = null;
        right = null;
        name = n;
        glutenFree = gf;
        calories = cal;
    }

    //dish display function
    public void display()
    {
        System.out.println(name);
        System.out.println("Calories: " + calories);
        System.out.print("Gluten Free: ");
        if(glutenFree == true)
            System.out.println("Yes");
        else
            System.out.println("No");
    }
}
