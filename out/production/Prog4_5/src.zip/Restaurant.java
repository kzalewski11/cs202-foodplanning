public abstract class Restaurant {
    protected Restaurant left;
    protected Restaurant right;
    protected Restaurant parent;
    protected Dish favorite;
    protected int priceRating;
    protected int healthRating;
    protected String name;
    protected boolean delivery;
    protected boolean red;


    //default constructor
    public Restaurant() {
        left = null;
        right = null;
        parent = null;
        favorite = null;
        priceRating = 0;
        healthRating = 0;
        delivery = true;
        red = false;
    }

    //get color
    public boolean isRed() {
        if (this == null)
            return false;
        return red;
    }

    //set color
    public void setRed(boolean r) {
        if (r == true) {
            red = true;
            return;
        }
        red = false;
    }

    //zero out information
    public void remove() {
        name = null;
        left = null;
        right = null;
    }

    //abstract base display
    public abstract void display();

    //get name
    public String getName() {
        if (this == null)
            return null;
        return name;

    }

    //go left
    public Restaurant goLeft() {
        return left;
    }

    //go right
    public Restaurant goRight() {
        return right;
    }

    //set left
    public void setLeft(Restaurant r) {
        left = r;
    }

    //set right
    public void setRight(Restaurant r) {
        right = r;
    }

    //set parent
    public void setParent(Restaurant r) {
        parent = r;
    }

    //get parent
    public Restaurant getParent() {
        return parent;
    }

    //get grandparent
    public Restaurant getGrandparent() {
        if (parent != null)
            return parent.parent;

        return null;
    }

    //get uncle
    public Restaurant getUncle() {
        if (parent == parent.parent.left)
            return parent.parent.right;

        return parent.parent.left;
    }

    //rotate left on current object
    public void rotateLeft(RBT t) {
        Restaurant temp = right;
        right = temp.left;

        if (temp.left != null)
            temp.left.parent = this;

        temp.parent = parent;

        if (parent == null)
            t.setRoot(temp);

        else if (this == parent.left)
            parent.left = temp;

        else
            parent.right = temp;

        temp.left = this;
        parent = temp;
    }

    //rotate right on current object
    public void rotateRight(RBT t) {
        Restaurant temp = left;
        left = temp.right;

        if(temp.right != null)
            temp.right.parent = this;

        temp.parent = parent;

        if(parent == null)
            t.setRoot(temp);

        else if (this == parent.right)
            parent.right = temp;

        else
            parent.left = temp;

        temp.right = this;
        parent = temp;
    }
}
