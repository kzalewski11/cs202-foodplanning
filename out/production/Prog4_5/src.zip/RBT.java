public class RBT {
    //root of Red-Black tree
    protected Restaurant root;

    //default constructor
    public RBT() {
        root = null;
    }

    //set root
    public void setRoot(Restaurant r) {
        root = r;
    }

    //insert Restaurant
    public Restaurant insert(Restaurant r) {
        //if root is null
        if(root == null)
            root = r;

        else
            insert(r, root);

        repair(r);
        return root;
    }

    //insert Restaurant recursive
    public void insert(Restaurant r, Restaurant root) {
        //if r is less than root
        if (root != null && r.getName().compareTo(root.getName()) < 0) {
            if (root.goLeft() != null) {
                insert(r, root.goLeft());
                return;
            } else
                root.setLeft(r);
        } else if (root != null) {
            if(root.goRight() != null) {
                insert(r, root.goRight());
                return;
            }
            else
                root.setRight(r);
        }
        r.setParent(root);
        r.setRed(true);
    }

    //repair tree
    public void repair(Restaurant r)
    {
        //if new node is root
        if(r == root)
        {
            r.setRed(false);
            return;
        }

        //if parent is black
        if(r.getParent() != null) {
            if (r.getParent().isRed() == false)
                return;
        }

        //if parent and uncle both red
        if(r.getParent() != null && r.getUncle() != null) {
            if (r.getParent().isRed() == true && r.getUncle().isRed() == true) {
                //repaint parent and uncle black, repaint grandparent red
                r.getParent().setRed(false);
                r.getUncle().setRed(false);
                if (r.getGrandparent() != null) {
                    r.getGrandparent().setRed(true);

                    //repair on grandparent
                    repair(r.getGrandparent());
                }
                return;
            }
        }
        //case 4: parent red, uncle black
        if(r.getParent().isRed() == true && r.getUncle() == null)
        {
            //if r is right child and r.parent is left child
            if(r == r.getParent().goRight() && r.getParent() == r.getGrandparent().goLeft())
            {
                r.getParent().rotateLeft(this);
                r = r.goLeft();
            }

            //if r is left child and r.parent is right child
            else if(r == r.getParent().goLeft() && r.getParent() == r.getGrandparent().goRight())
            {
                r.getParent().rotateRight(this);
                r = r.goRight();
            }

            //if r is left child
            if(r == r.getParent().goLeft())
                r.getGrandparent().rotateRight(this);

                //if r is right child
            else
                r.getGrandparent().rotateLeft(this);

            //set parent black
            r.getParent().setRed(false);
            r.getParent().goRight().setRed(true);

            //if grandparent exists
            if(r.getGrandparent() != null)
                //set grandparent red
                r.getGrandparent().setRed(true);
        }
    }

    //display tree
    public void display(){
        //if tree is empty
        if(root == null)
            return;

        //if tree only has one node
        if(root.goLeft() == null && root.goRight() == null) {
            root.display();
            return;
        }

        //if tree has more than one node
        display(root);
    }

    //display tree recursively
    public void display(Restaurant root) {
        //if left subtree exists
        if (root.goLeft() != null)
            display(root.goLeft());

        //display node
        root.display();

        //if right subtree exists
        if (root.goRight() != null)
            display(root.goRight());
    }

    //find restaurant in tree
    public boolean find(String name)
    {
        //if tree is empty
        if(root == null)
            return false;

        return find(name, root);
    }

    //find restaurant recursive
    public boolean find(String name, Restaurant root)
    {
        //if name is less than root
        if(name.compareTo(root.getName()) < 0) {
            if (root.goLeft() != null)
                return find(name, root.goLeft());
            return false;
        }

        //if name is greater than root
        if(name.compareTo(root.getName()) > 0)
        {
            if(root.goRight() != null)
                return find(name, root.goRight());
            return false;
        }

        return true;
    }

    //retrieve related wrapper
    public void retrieveRelated(Restaurant r)
    {
        //if tree is empty
        if(root == null)
            return;

        //if tree only has one item
        if(root.goLeft() == null && root.goRight() == null) {
            if (r.getClass() == root.getClass())
                r.display();
        }

        //if tree has more than one item
        retrieveRelated(r, root);
    }

    //retrieve related recursive
    public void retrieveRelated(Restaurant r, Restaurant root) {
        //traverse left
        if (root.goLeft() != null)
            retrieveRelated(r, root.goLeft());

        //visit root
        if (r.getClass() == root.getClass())
            root.display();

        //traverse right
        if (root.goRight() != null)
            retrieveRelated(r, root.goRight());
    }

    //remove all items from tree wrapper
    public void removeAll()
    {
        //if tree is empty
        if(root == null)
            return;

        //if tree has only one node
        if(root.goLeft() == null && root.goRight() == null) {
            root.remove();
            root = null;
            return;
        }

        //if tree has multiple nodes
        removeAll(root);
    }

    //remove all items recursively
    public void removeAll(Restaurant root)
    {
        //traverse left
        if(root.goLeft() != null)
            removeAll(root.goLeft());

        //traverse right
        if(root.goRight() != null)
            removeAll(root.goRight());

        //delete root info
        root.remove();
        root = null;
    }

}
