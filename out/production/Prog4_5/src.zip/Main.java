public class Main {

    public static void main(String[] args) {

        //create Red-Black tree
        RBT r = new RBT();

        //create some restaurants
        Restaurant r1 = new Chinese("Panda Express", "Orange Chicken", 500, false);
        Restaurant r2 = new Mexican("Don Pedro", "Chimichanga", 600, false);
        Restaurant r3 = new Vegetarian("Happy Broccoli", "Kale Salad", 250, true);
        Restaurant r4 = new Chinese("New Buffet", "Teriyaki Chicken", 450, false);
        Restaurant r5 = new Mexican("Senor Lopez", "Quesadilla", 550, false);
        Restaurant r6 = new Vegetarian("Healthy Skepticism", "Dehydrated Bean Chips", 120, true);

        //insert restaurants into tree
        /*
        r.insert(r1);
        r.insert(r2);
        r.insert(r3);
        r.insert(r4);
        r.insert(r5);
        r.insert(r6);*/

        r.setRoot(r.insert(r1));
        r.setRoot(r.insert(r2));
        r.setRoot(r.insert(r3));
        r.setRoot(r.insert(r4));
        r.setRoot(r.insert(r5));
        r.setRoot(r.insert(r6));


        //display tree
        r.display();

        //find restaurants
        boolean found = r.find("Panda Express");
        //boolean found = r.find("Don Pedro");
        //boolean found = r.find("Happy Broccoli");
        //boolean found = r.find("New Buffet");
        //boolean found = r.find("Senor Lopez");
        //boolean found = r.find("Healthy Skepticism");
        //boolean found = r.find("Unhealthy Skepticism");

        if(found == true)
            System.out.println("Restaurant was found");
        else
            System.out.println("Restaurant not found");

        //retrieve related
        System.out.println("Retrieving related restaurants: ");
        r.retrieveRelated(r3);


        //remove all entries from tree
        r.removeAll();
    }
}
